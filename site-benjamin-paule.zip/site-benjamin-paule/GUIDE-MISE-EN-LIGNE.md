# Site benjamin-paule.me : guide de mise en ligne

Ce dossier contient ton nouveau portfolio, prêt à être publié. Il n'y a rien à installer ni à compiler : ce sont des pages HTML, une feuille de style et une petite API pour le formulaire.

## Ce qu'il y a dans le dossier

```
site-benjamin-paule/
├── public/                  ← le site (ce que voient les visiteurs)
│   ├── index.html           accueil + formulaire de contact
│   ├── mentions-legales.html, confidentialite.html (RGPD), cgu.html, 404.html
│   ├── demos/               3 sites de démonstration (garage, coiffure, plombier)
│   ├── assets/css, assets/js, assets/img
│   ├── favicon.*, apple-touch-icon.png, icon-*.png, og-image.jpg (image de partage)
│   ├── sitemap.xml, robots.txt, site.webmanifest
│   ├── _headers             sécurité : HTTPS forcé, anti-clickjacking, CSP…
│   └── _redirects           anciennes adresses → accueil
├── functions/api/contact.js ← l'API du formulaire, exécutée sur le serveur (jamais dans le navigateur)
└── tests/contact.test.mjs   tests de l'API (lancer : node tests/contact.test.mjs)
```

## Tes règles, et où elles sont appliquées

| Règle | Comment c'est fait |
|---|---|
| Page RGPD | `/confidentialite` : données, durée, sous-traitants, droits, CNIL |
| Page CGU | `/cgu`. J'ai ajouté `/mentions-legales`, qui est **obligatoire par la loi** pour un pro |
| API hors du front | `functions/api/contact.js` tourne sur les serveurs Cloudflare. Les clés secrètes n'apparaissent jamais dans le code du site |
| HTTPS forcé | En-tête HSTS dans `_headers` + réglage « Always Use HTTPS » (étape 6) |
| Bandeau cookies | Accepter / Refuser avec le même poids (exigence CNIL), choix gardé 6 mois, lien « Gérer les cookies » en bas de page |
| Meta title et description | Sur chaque page, uniques |
| Image de partage réseaux sociaux | `og-image.jpg` 1200×630 + balises Open Graph et Twitter |
| Favicon | `.ico`, `.svg`, icône Apple et icônes Android |
| Sitemap et robots.txt | `sitemap.xml`, `robots.txt` (les démos et l'API sont exclues) |
| Texte alternatif | Toutes les images ont un `alt` descriptif |
| Vitesse de chargement | Lighthouse mobile : **98 à 100/100** en performance, affichage en ~1 s, 0 décalage de mise en page |
| Contraste des couleurs | Toutes les couleurs sont au niveau AA ou mieux. Lighthouse accessibilité : **100/100** |
| Responsive | Testé de 320 px à 1280 px de large, aucun débordement |
| Page 404 personnalisée | `404.html` (Cloudflare l'utilise automatiquement) |
| Liens cassés | Vérifiés avec linkinator : 0 lien cassé |
| Validation des formulaires | Dans le navigateur (messages clairs en français) **et** sur le serveur (on ne fait jamais confiance au navigateur) |
| Anti-spam | Cloudflare Turnstile (sans puzzle agaçant) + champ piège invisible + contrôle de l'origine et de la taille des messages |
| Analytics | Umami : pages vues, provenance, appareils, et clics sur le bouton « maquette gratuite » (par position), envois réussis du formulaire. Chargé seulement après « Accepter » |
| Un seul CTA | Partout le même : « Recevoir ma maquette gratuite », qui mène au formulaire |

---

## Mise en ligne, étape par étape

Tout est gratuit. Compte environ 1 heure la première fois.

### Étape 1 : mettre le code sur GitHub
1. Va sur github.com et crée un nouveau dépôt, par exemple `site-benjamin-paule` (Private, c'est très bien).
2. Clique sur **« uploading an existing file »**, puis glisse-dépose **le contenu** du dossier `site-benjamin-paule` : les dossiers `public`, `functions`, `tests` et ce guide.
3. Clique sur **Commit changes**.

### Étape 2 : créer le site sur Cloudflare Pages
1. Crée un compte gratuit sur **dash.cloudflare.com**.
2. Menu **Workers & Pages** → **Create** → onglet **Pages** → **Connect to Git** → choisis ton dépôt.
3. Réglages de build :
   - Framework preset : **None**
   - Build command : **(laisser vide)**
   - Build output directory : **`public`**
4. **Save and Deploy**. Ton site est en ligne sur une adresse du type `site-benjamin-paule.pages.dev`.

### Étape 3 : l'anti-spam (Turnstile)
1. Dans Cloudflare, menu **Turnstile** → **Add widget**.
2. Nom : `benjamin-paule.me`. Domaines : `benjamin-paule.me` et ton adresse `….pages.dev`. Mode : **Managed**.
3. Tu obtiens une **Site Key** (publique) et une **Secret Key** (secrète).
4. Dans `public/index.html`, cherche `data-turnstile-sitekey="1x00000000000000000000AA"` et remplace cette clé de test par ta **Site Key**.
   ⚠️ Tant que la clé de test est là, l'anti-spam laisse tout passer.
5. Dans ton projet Pages → **Settings** → **Variables and Secrets** → ajoute `TURNSTILE_SECRET` = ta Secret Key (type **Secret**).

### Étape 4 : recevoir les demandes par e-mail (Resend)
1. Crée un compte gratuit sur **resend.com** avec l'adresse mail sur laquelle tu veux recevoir les demandes.
2. **API Keys** → **Create API Key** → copie-la.
3. Dans Cloudflare Pages → **Variables and Secrets**, ajoute :
   - `RESEND_API_KEY` = la clé (type **Secret**)
   - `CONTACT_TO` = **la même adresse que ton compte Resend** (obligatoire tant que ton domaine n'est pas vérifié chez Resend)
4. Plus tard (facultatif) : vérifie ton domaine dans Resend (**Domains**), puis ajoute `CONTACT_FROM` = `Site <contact@benjamin-paule.me>`.
5. Refais un déploiement pour que les variables soient prises en compte : **Deployments** → **Retry deployment**.

### Étape 5 : les statistiques (Umami)
1. Crée un compte gratuit sur **cloud.umami.is**. Si on te propose une région de stockage, choisis l'Europe.
2. **Add website** → nom `benjamin-paule.me`, domaine `benjamin-paule.me`.
3. Copie le **Website ID**.
4. Dans `public/assets/js/main.js`, remplace `REMPLACER-PAR-TON-ID-UMAMI` par cet identifiant.
5. Dans Umami, tu verras les visites, les pages vues, d'où viennent les visiteurs, et les événements `cta-maquette` (avec l'endroit du clic) et `formulaire-succes`.

### Étape 6 : brancher ton nom de domaine
Ton domaine pointe aujourd'hui vers GitHub Pages. On le passe chez Cloudflare :
1. Dans Cloudflare : **Add a domain** → `benjamin-paule.me` → offre **Free**.
2. Cloudflare importe tes anciens réglages DNS. **Supprime les 4 enregistrements A** qui commencent par `185.199.` et l'éventuel CNAME `www` qui pointe vers `github.io` : ce sont ceux de GitHub Pages.
3. Cloudflare te donne **2 serveurs de noms**. Va là où tu as acheté le domaine (souvent Namecheap si c'était avec le GitHub Student Pack), et remplace les serveurs de noms par ceux de Cloudflare. L'activation peut prendre de quelques minutes à 24 h.
4. Dans ton projet Pages → **Custom domains** → ajoute `benjamin-paule.me`, puis `www.benjamin-paule.me`.
5. **SSL/TLS** → **Edge Certificates** → active **Always Use HTTPS**.
6. **Rules** → **Redirect Rules** → modèle **« Redirect from WWW to root »**, pour que www renvoie vers l'adresse principale.
7. Dans ton ancien dépôt GitHub Pages : **Settings** → **Pages** → retire le domaine personnalisé, pour éviter les conflits.

### Étape 7 : ton adresse contact@benjamin-paule.me
- **Pour recevoir** (le plus simple) : Cloudflare → **Email** → **Email Routing** → crée `contact@benjamin-paule.me` qui transfère vers ta boîte Gmail. C'est gratuit et prend 2 minutes.
- **Pour aussi envoyer depuis cette adresse** : prends une vraie boîte mail sur ton domaine, par exemple Zoho Mail si son offre gratuite existe toujours. Dans ce cas, n'active pas l'Email Routing : les deux se gênent.

### Étape 8 : compléter les infos légales
Dans `public/mentions-legales.html` et `public/confidentialite.html`, cherche **« À compléter »** et remplis :
- ton **adresse** (celle déclarée pour la micro-entreprise ; si tu ne veux pas afficher ton domicile, il existe des sociétés de domiciliation) ;
- ton **SIRET**, dès que tu le reçois.

### Étape 9 : vérifier que tout marche
- [ ] Le site s'ouvre sur https://benjamin-paule.me avec le cadenas
- [ ] http://benjamin-paule.me et www.benjamin-paule.me renvoient bien vers https://benjamin-paule.me
- [ ] Envoie-toi une demande via le formulaire : tu dois recevoir l'e-mail
- [ ] Clique sur « Accepter » dans le bandeau, puis vérifie qu'une visite apparaît dans Umami
- [ ] Colle ton adresse dans https://www.opengraph.xyz pour voir l'aperçu sur les réseaux sociaux
- [ ] Déclare ton `sitemap.xml` dans **Google Search Console**, pour que Google trouve ton site plus vite

---

## Modifier le site plus tard
- **Changer un texte** : modifie le fichier `.html` directement sur GitHub (bouton ✏️), puis **Commit**. Cloudflare remet le site à jour tout seul en une minute.
- **Ajouter une vraie réalisation** : copie un bloc `<article class="card project">` dans `index.html`, change l'image, le texte alternatif et le lien.
- **Ajouter une page** : pense à l'ajouter dans `sitemap.xml`.
